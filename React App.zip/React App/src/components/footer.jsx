

import React from 'react';
import Bootstrap from 'bootstrap/dist/css/bootstrap.css'


export default class footer extends React.Component {
    render() {
        return (
            
           <center><footer>World of Yoga</footer></center>

        );
    }
}